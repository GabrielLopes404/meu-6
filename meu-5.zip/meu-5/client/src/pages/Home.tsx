import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { ServicesOverview } from "@/components/ServicesOverview";
import { Services } from "@/components/Services";
import { WebDevelopment } from "@/components/WebDevelopment";
import { TrafficManagement } from "@/components/TrafficManagement";
import { Portfolio } from "@/components/Portfolio";
import { BeforeAfterSection } from "@/components/BeforeAfter";
import { Stats } from "@/components/Stats";
import { Differentiators } from "@/components/Differentiators";
import { Testimonials } from "@/components/Testimonials";
import { FAQ } from "@/components/FAQ";
import { FinalCTA } from "@/components/FinalCTA";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <ServicesOverview />
        
        {/* BLOCO COMPLETO DE DESIGN GRÁFICO - TUDO JUNTO */}
        <Services />
        <Differentiators />
        <Portfolio />
        <BeforeAfterSection />
        
        {/* MÉTRICAS E PROVAS SOCIAIS */}
        <Stats />
        
        {/* BLOCO DE SOLUÇÕES DIGITAIS */}
        <WebDevelopment />
        <TrafficManagement />
        
        {/* BLOCO DE DEPOIMENTOS E FAQ */}
        <Testimonials />
        <FAQ />
        
        {/* CHAMADA FINAL */}
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}
