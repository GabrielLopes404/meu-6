import { useState, useEffect, useRef } from "react";
import { Eye, Sparkles, Box, Video, Zap } from "lucide-react";

export function Differentiators() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const services = [
    {
      icon: Eye,
      title: "Identidade Visual",
      description: "Identidade visual forte, moderna e memorável pra sua marca se destacar.",
      angle: -45,
    },
    {
      icon: Sparkles,
      title: "Peças para Mídias",
      description: "Criações impactantes que atraem, comunicam e vendem mais.",
      angle: 45,
    },
    {
      icon: Box,
      title: "Modelagem 3D",
      description: "Modelagens únicas e originais para dar vida à sua ideia ou marca.",
      angle: -135,
    },
    {
      icon: Video,
      title: "Pacote Audiovisual",
      description: "Designs completos, bonitos e funcionais prontos para usar em projetos digitais.",
      angle: 135,
    },
    {
      icon: Zap,
      title: "Edições para Internet",
      description: "Tudo que sua marca precisa em um só lugar: qualidade, agilidade e preço justo.",
      angle: 180,
    },
  ];

  return (
    <section ref={sectionRef} className="py-20 md:py-32 bg-[#0a0012] relative overflow-hidden" data-testid="section-differentiators">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/20 via-primary/5 to-transparent"></div>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#0a0012]"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 border border-primary/40 mb-4 shadow-[0_0_20px_rgba(236,72,153,0.3)]">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary uppercase tracking-wider">Meus Serviços</span>
          </div>
          <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl uppercase tracking-tight text-white">
            O que eu <span className="text-primary">faço</span>
          </h2>
        </div>

        <div className="relative max-w-5xl mx-auto min-h-[500px] sm:min-h-[600px] md:min-h-[700px] flex items-center justify-center">
          <div className="relative w-full h-[500px] sm:h-[600px] md:h-[700px]">
            {/* Central Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[250px] h-[250px] sm:w-[350px] sm:h-[350px] md:w-[400px] md:h-[400px] rounded-full bg-gradient-to-br from-primary/30 via-primary/20 to-primary/10 blur-3xl"></div>
            
            {/* Pulsing Rings */}
            <div 
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[320px] h-[320px] sm:w-[420px] sm:h-[420px] md:w-[500px] md:h-[500px] rounded-full border-[2px] border-primary/20 opacity-40"
              style={{
                animation: isVisible ? 'pulse 8s ease-in-out infinite' : 'none'
              }}
            ></div>
            
            <div 
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[260px] h-[260px] sm:w-[340px] sm:h-[340px] md:w-[400px] md:h-[400px] rounded-full border-[2px] border-primary/30 opacity-50"
              style={{
                animation: isVisible ? 'pulse 6s ease-in-out infinite 0.5s' : 'none'
              }}
            ></div>
            
            <div 
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[200px] h-[200px] sm:w-[260px] sm:h-[260px] md:w-[300px] md:h-[300px] rounded-full border-[2px] border-primary/40 opacity-60"
              style={{
                animation: isVisible ? 'pulse 4s ease-in-out infinite 1s' : 'none'
              }}
            ></div>
            
            {/* Center Circle with Image */}
            <div 
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[160px] h-[160px] sm:w-[200px] sm:h-[200px] md:w-[240px] md:h-[240px] rounded-full bg-black flex items-center justify-center ring-4 ring-primary/50 shadow-[0_0_60px_rgba(236,72,153,0.6)] sm:shadow-[0_0_80px_rgba(236,72,153,0.6)] overflow-hidden"
            >
              <div className="w-[145px] h-[145px] sm:w-[185px] sm:h-[185px] md:w-[220px] md:h-[220px] rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-2xl overflow-hidden">
                <img 
                  src="/attached_assets/image_1763746186609.png" 
                  alt="Design 3D" 
                  className="w-full h-full object-cover scale-150"
                  style={{
                    animation: isVisible ? 'spin 20s linear infinite' : 'none'
                  }}
                />
              </div>
            </div>

            {/* Service Cards in Circle */}
            {services.map((service, index) => {
              const radiusMobile = 180;
              const radiusTablet = 220;
              const radiusDesktop = 280;
              const angleInRadians = (service.angle * Math.PI) / 180;
              
              return (
                <div
                  key={index}
                  className="absolute top-1/2 left-1/2"
                  style={{
                    transform: `translate(calc(-50% + ${Math.cos(angleInRadians) * radiusMobile}px), calc(-50% + ${Math.sin(angleInRadians) * radiusMobile}px))`,
                  }}
                  data-testid={`card-differentiator-${index}`}
                >
                  <style>{`
                    @media (min-width: 640px) {
                      [data-testid="card-differentiator-${index}"] {
                        transform: translate(calc(-50% + ${Math.cos(angleInRadians) * radiusTablet}px), calc(-50% + ${Math.sin(angleInRadians) * radiusTablet}px)) !important;
                      }
                    }
                    @media (min-width: 768px) {
                      [data-testid="card-differentiator-${index}"] {
                        transform: translate(calc(-50% + ${Math.cos(angleInRadians) * radiusDesktop}px), calc(-50% + ${Math.sin(angleInRadians) * radiusDesktop}px)) !important;
                      }
                    }
                  `}</style>
                  <div 
                    className="group relative -translate-x-1/2 -translate-y-1/2"
                    style={{
                      animation: isVisible ? `floatCard 3s ease-in-out infinite ${index * 0.2}s` : 'none',
                    }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-primary/10 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
                    <div className="relative bg-gradient-to-br from-[#1a0a28] via-[#0f0518] to-[#1f0a30] backdrop-blur-sm border-[1.5px] border-primary/40 rounded-2xl p-4 sm:p-5 md:p-6 shadow-[0_0_30px_rgba(236,72,153,0.35)] hover:shadow-[0_0_50px_rgba(236,72,153,0.5)] transition-all duration-300 hover:scale-105 w-[180px] sm:w-[210px] md:w-[240px]">
                      <div className="flex items-start gap-2 sm:gap-3 mb-2 sm:mb-3">
                        <div className="flex-shrink-0 w-8 h-8 sm:w-9 sm:h-9 md:w-10 md:h-10 rounded-full bg-black border-[1.5px] border-primary/50 flex items-center justify-center shadow-lg">
                          <service.icon className="w-4 h-4 sm:w-4.5 sm:h-4.5 md:w-5 md:h-5 text-primary" />
                        </div>
                        <h3 className="font-display font-bold text-base sm:text-base md:text-lg leading-tight text-white" data-testid={`text-differentiator-title-${index}`}>
                          {service.title}
                        </h3>
                      </div>
                      <p className="text-xs sm:text-sm text-white/70 leading-relaxed" data-testid={`text-differentiator-desc-${index}`}>
                        {service.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
