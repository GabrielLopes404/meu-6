import { Button } from "@/components/ui/button";
import { ArrowDown, Sparkles, Code2, Palette } from "lucide-react";
import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useState } from "react";

export function Hero() {
  const [isClient, setIsClient] = useState(false);
  const { scrollY } = useScroll();
  
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);
  const scale = useTransform(scrollY, [0, 300], [1, 0.95]);
  const y = useTransform(scrollY, [0, 300], [0, 50]);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const scrollToPortfolio = () => {
    const element = document.getElementById("portfolio");
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  };

  const titleVariants = {
    hidden: { scale: 0.8, opacity: 0 },
    visible: {
      scale: 1,
      opacity: 1,
      transition: {
        duration: 1,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#050505]" data-testid="section-hero">
      {/* Animated Grid Background */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.5 }}
        className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:4rem_4rem] md:bg-[size:6rem_6rem]"
      />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-transparent to-transparent" />
      
      {/* Floating Orbs - Responsive sizes */}
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{
          opacity: [0.3, 0.5, 0.3],
          scale: [1, 1.1, 1],
          x: [0, 20, 0],
          y: [0, -20, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute top-1/4 left-[5%] md:left-[10%] w-48 h-48 md:w-96 md:h-96 bg-primary/30 rounded-full blur-[80px] md:blur-[140px]"
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{
          opacity: [0.2, 0.4, 0.2],
          scale: [1, 1.2, 1],
          x: [0, -30, 0],
          y: [0, 20, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1,
        }}
        className="absolute bottom-1/4 right-[5%] md:right-[10%] w-64 h-64 md:w-[500px] md:h-[500px] bg-primary/20 rounded-full blur-[100px] md:blur-[160px]"
      />
      
      {/* Central Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full max-w-4xl opacity-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,#ff00c8_0%,transparent_70%)]"></div>
      </div>

      <motion.div
        style={isClient ? { opacity, scale, y } : {}}
        className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 sm:pt-28 md:pt-32 pb-16 sm:pb-20 text-center"
      >
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-6 sm:space-y-8 md:space-y-10"
        >
          {/* Badge */}
          <motion.div variants={itemVariants} className="flex justify-center">
            <div className="inline-flex items-center gap-2 sm:gap-3 px-3 sm:px-5 py-2 sm:py-2.5 rounded-full bg-gradient-to-r from-primary/20 to-primary/10 border border-primary/40 shadow-[0_0_20px_rgba(236,72,153,0.3)] sm:shadow-[0_0_30px_rgba(236,72,153,0.3)]">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <Palette className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                <span className="text-white/90 text-xs sm:text-sm font-medium">Design Gráfico</span>
              </div>
              <div className="w-px h-3 sm:h-4 bg-primary/40"></div>
              <div className="flex items-center gap-1.5 sm:gap-2">
                <Code2 className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                <span className="text-white/90 text-xs sm:text-sm font-medium">Desenvolvimento Web</span>
              </div>
            </div>
          </motion.div>

          {/* Main Title with Split Animation */}
          <motion.div variants={titleVariants} className="space-y-2 sm:space-y-4 md:space-y-6">
            <h1 className="font-display font-black text-4xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-[10rem] tracking-tight leading-none" data-testid="text-hero-title">
              <motion.span
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
                className="block text-white uppercase drop-shadow-2xl"
                style={{ letterSpacing: "-0.03em" }}
              >
                LOPES
              </motion.span>
              <motion.span
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
                className="block text-transparent bg-clip-text bg-gradient-to-r from-primary via-pink-500 to-primary uppercase relative"
                style={{ letterSpacing: "-0.03em" }}
              >
                DESIGNER
                <motion.div
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ duration: 1, delay: 1, ease: [0.22, 1, 0.36, 1] }}
                  className="absolute -bottom-2 sm:-bottom-4 left-1/2 -translate-x-1/2 w-24 sm:w-48 h-1 sm:h-1.5 bg-gradient-to-r from-transparent via-primary to-transparent shadow-[0_0_20px_rgba(236,72,153,0.8)]"
                />
              </motion.span>
            </h1>
          </motion.div>

          {/* Subtitle */}
          <motion.p
            variants={itemVariants}
            className="max-w-xs sm:max-w-2xl md:max-w-3xl mx-auto text-base sm:text-xl md:text-2xl text-white/70 font-body leading-relaxed px-4 sm:px-0"
            data-testid="text-hero-subtitle"
          >
            Transformo marcas com <span className="text-primary font-bold">design estratégico</span> e{" "}
            <span className="text-primary font-bold">sites profissionais</span> que atraem, encantam e convertem.
            <br className="hidden sm:block" />
            <span className="text-white/50 text-sm sm:text-lg mt-2 sm:mt-3 block">
              Mais de <span className="text-primary font-semibold">350 projetos</span> entregues com excelência.
            </span>
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            variants={itemVariants}
            className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-5 pt-4 sm:pt-8 px-4 sm:px-0"
          >
            <motion.a
              href="https://www.instagram.com/lopesdesigner_ofc/"
              target="_blank"
              rel="noopener noreferrer"
              data-testid="button-cta-hero"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                size="lg"
                className="w-full sm:w-auto text-sm sm:text-base px-6 sm:px-10 py-5 sm:py-7 bg-gradient-to-r from-primary to-pink-600 hover:from-pink-600 hover:to-primary relative overflow-hidden group shadow-[0_0_30px_rgba(236,72,153,0.5)] hover:shadow-[0_0_60px_rgba(236,72,153,0.8)] transition-all border-0"
              >
                <span className="relative z-10 flex items-center gap-2 sm:gap-3 font-bold uppercase tracking-wide">
                  <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />
                  <span className="text-xs sm:text-base">SOLICITAR MEU PROJETO</span>
                </span>
                <motion.div
                  className="absolute inset-0 bg-white/20"
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                />
              </Button>
            </motion.a>
            <motion.button
              onClick={scrollToPortfolio}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-full sm:w-auto px-6 sm:px-10 py-5 sm:py-7 text-sm sm:text-base font-bold text-white border-2 border-white/20 hover:border-primary/60 rounded-lg transition-all hover:bg-white/5 backdrop-blur-sm uppercase tracking-wide"
            >
              VER PORTFOLIO
            </motion.button>
          </motion.div>

          {/* Scroll Indicator */}
          <motion.div
            variants={itemVariants}
            className="pt-8 sm:pt-16"
          >
            <motion.button
              onClick={scrollToPortfolio}
              className="inline-flex flex-col items-center gap-2 text-white/50 hover:text-primary transition-colors group"
              data-testid="button-scroll-down"
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            >
              <span className="text-xs uppercase tracking-widest font-semibold">Descubra meu trabalho</span>
              <ArrowDown className="w-5 h-5 sm:w-6 sm:h-6 group-hover:text-primary" />
            </motion.button>
          </motion.div>
        </motion.div>
      </motion.div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-24 sm:h-32 bg-gradient-to-t from-[#050505] to-transparent pointer-events-none"></div>
    </section>
  );
}
